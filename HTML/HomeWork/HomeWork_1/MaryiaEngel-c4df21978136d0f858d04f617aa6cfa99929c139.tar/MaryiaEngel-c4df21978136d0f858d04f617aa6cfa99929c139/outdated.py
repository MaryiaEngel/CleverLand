months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]
while True:
    n = input("Date: ")
    try:
        nmonth,nday,year = n.split("/")
        year = year.replace(" ","")
        if (1 <= int(nmonth) <= 12) and (1 <= int(nday) <= 31):
            break
    except:
        try:
            month,day,year = n.split(" ")
            for i in range(len(months)):
                if month == months[i]:
                    nmonth = i+1
                nday=day.replace(",","")
            if (1 <= int(nmonth) <= 12) and (1 <= int(nday) <= 31):
                break
        except:
            print()
            pass



print(f"{year}-{int(nmonth):02}-{int(nday):02}")